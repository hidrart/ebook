<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Book')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white rounded-lg p-6">
                User Detail Page
            </div>
            <div class="mt-10 flex justify-end space-x-4">
                <a href="<?php echo e(url()->previous()); ?>"
                    class="bg-indigo-200 py-2 px-4 text-indigo-700 rounded-lg cursor-pointer flex items-center space-x-2">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                    </span>
                    <span>
                        Back
                    </span>
                </a>

            </div>
            <div class="flex items-center border-b border-slate-100 p-6 mt-10 bg-white rounded-lg space-x-2">
                <div class="w-10 h-10">
                    <img src="<?php echo e(url("https://i.pravatar.cc/150?u=<?php echo $user->email; ?>")); ?>"
                    alt="avatar"
                    class="w-full h-full rounded-full" />
                </div>
                <div class="flex flex-col">
                    <div class="flex space-x-1 items-center">
                        <h3 class="ml-3 font-bold text-gray-800"><?php echo e($user->name); ?></h3>
                        <?php if($user->role == 'admin'): ?>
                        <div class="pt-0.5">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-indigo-700" viewBox="0 0 20 20"
                                fill="currentColor">
                                <path fill-rule="evenodd"
                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                    clip-rule="evenodd" />
                            </svg>
                        </div>
                        <?php endif; ?>
                    </div>
                    <p class=" ml-3 text-sm"><?php echo e($user->email); ?></p>
                </div>
            </div>
            <div class="p-10 mt-10 bg-white rounded-lg">
                <h2 class="text-lg font-bold">Edit User Data</h2>
                <form method="POST" action="<?php echo e(url("/profile/edit")); ?>" class="mt-8 flex flex-col items-start
                    gap-6" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.validation-errors','data' => ['class' => 'mb-2','errors' => $errors]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <label class="block w-full">
                        <span class="text-gray-700">Username</span>
                        <input type="text" name="name"
                            class="rounded-md border-0 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 w-full bg-gray-100 mt-2"
                            value="<?php echo e(old('name', $user->name)); ?>">
                    </label>
                    <label class="block w-full">
                        <span class="text-gray-700">User email</span>
                        <input type="email" name="email"
                            class="rounded-md border-0 w-full bg-gray-100 text-gray-400 mt-2"
                            value="<?php echo e(old('email', $user->email)); ?>" disabled>
                    </label>
                    <label class="block w-full">
                        <span class="text-gray-700">Choose profile photo</span>
                        <input type="file" name="image"
                            class="w-full text-slate-500 bg-gray-100 rounded-md file:mr-4  file:py-2.5 file:px-4 file:rounded-l-md file:border-0 file:bg-indigo-200 file:text-indigo-700 file:font-sans mt-2 file:cursor-pointer" />
                    </label>
                    <label class="block w-full">
                        <span class="text-gray-700">User Role</span>
                        <select name="role" id="role"
                            class="w-full bg-gray-100 rounded-md mt-2 border-0 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                            <option value="" disabled>Role</option>
                            <option value="user" <?php if(old('role', $user->role) == 'user'): ?> selected <?php endif; ?>>User</option>
                            <option value="admin" <?php if(old('role', $user->role) == 'admin'): ?> selected <?php endif; ?>>Admin
                            </option>
                        </select>
                    </label>
                    <div class="flex justify-end w-full">
                        <button type="submit"
                            class=" bg-indigo-200 py-2 px-4 text-indigo-700 rounded-lg cursor-pointer flex items-center space-x-2 mt-4">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                                </svg>
                            </span>
                            <span>
                                Save
                            </span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\hiday\Downloads\Ongoing\amazing-ebook\resources\views/user/detail.blade.php ENDPATH**/ ?>